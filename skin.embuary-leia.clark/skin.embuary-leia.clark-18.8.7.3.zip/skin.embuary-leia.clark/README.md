Forked from sualfred with these changes:
- pausing player does not show OSD 
- reduced time OSD is shown after seeking frmo 2s to 0.5s
Both changes are for improved visibility of subtitles, particularly when in a foreign language that takes longer to read.

# skin.embuary
Embuary is based on the web UI of Emby and has been developed for Emby-For-kodi users, but it doesn't require Emby at all and will also work with a regular Kodi setup.

# Terms of use
With the installation of the skin you agree that you don't use it in combination with blacklisted and illegal Kodi add-ons.
I'm not associated with any available build and I won't give any support to blacklisted, banned or illegal third party addons.

# License
This work has been released under CC by-nc-nd 4.0.

You are allowed to:
- Change whatever if you want to use it for your your personal use, but don't share it to the public. That restriction also applies to public GitHub repositories.
- If you fork and add your personal modifications you are allowed to release it to the public if you don't change the addon title/name to someting complete different (rebranding). Modification tags behind the addon title are okay. Example: ID "skin.embuary-moddedbyme" Name "Embuary Skin - Modded by me". The addon.xml has to include proper credits and the information that it's a fork based on my work. The license model cannot be changed.
